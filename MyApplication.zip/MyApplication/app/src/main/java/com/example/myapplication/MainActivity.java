package com.example.myapplication;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.res.Resources;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import java.io.IOException;
import java.net.Socket;
import java.io.PrintWriter;
import java.security.InvalidKeyException;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.security.Signature;
import java.security.SignatureException;
import java.util.Base64;

public class MainActivity extends AppCompatActivity {

    // Setup Server information
    protected static String server = "10.0.2.2";
    protected static int port = 7070;
    private  String cNumber;
    private  String sNumber;
    private  String mNumber;
    private String idC;
    private byte[] firma;
    private Socket client;
    private PrintWriter printwriter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Capturamos el boton de Enviar
        View button = findViewById(R.id.button_send);

        // Llama al listener del boton Enviar
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showDialog();
            }
        });


    }

    // Creación de un cuadro de dialogo para confirmar pedido
    private void showDialog() throws Resources.NotFoundException {

        EditText sabanasNumber = (EditText) findViewById(R.id.sabanasNumber);
        sNumber = sabanasNumber.getText().toString();
        EditText colchasNumber = (EditText) findViewById(R.id.colchasNumber);
        cNumber = colchasNumber.getText().toString();
        EditText mantasNumber = (EditText) findViewById(R.id.mantasNumber);
        mNumber = mantasNumber.getText().toString();
        EditText idClient = (EditText) findViewById(R.id.idClient);
        idC = idClient.getText().toString();

        if (sNumber.matches("") && cNumber.matches("") && mNumber.matches("")) {
            Toast.makeText(this, "Rellena al menos un campo", Toast.LENGTH_SHORT).show();
            return;

        }else if (idC.matches("")) {
            Toast.makeText(this, "Introduce tu ID de cliente", Toast.LENGTH_SHORT).show();
            return;

        } else {
            new AlertDialog.Builder(this)
                    .setTitle("Enviar")
                    .setMessage("Se va a proceder al envio")
                    .setIcon(android.R.drawable.ic_dialog_alert)
                    .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {

                                // Catch ok button and send information
                                @RequiresApi(api = Build.VERSION_CODES.O)
                                public void onClick(DialogInterface dialog, int whichButton) {


                                    if(sNumber.equals("")){sNumber="0";}
                                    if(cNumber.equals("")){cNumber="0";}
                                    if(mNumber.equals("")){mNumber="0";}
                                    // 1. Extraer los datos de la vista
                                    String jsonRes= "sNumber:"+sNumber +",cNumber:"+cNumber +",mNumber:"+ mNumber+",idClient:"+ idC+"";
                                    // 2. Firmar los datos
                                    KeyPairGenerator kgen = null;
                                    try {
                                        kgen = KeyPairGenerator.getInstance("RSA");
                                        kgen.initialize(2048);
                                        KeyPair keys = kgen.generateKeyPair();

                                        Signature sg = Signature.getInstance("SHA256withRSA");
                                        sg.initSign(keys.getPrivate());
                                        sg.update(jsonRes.getBytes());
                                        firma = sg.sign();
                                        String publicKey = Base64.getEncoder().encodeToString(keys.getPublic().getEncoded());

                                        jsonRes= "sNumber:"+sNumber +";cNumber:"+cNumber +";mNumber:"+ mNumber+
                                                ";idClient:"+ idC + ";firma:"+ firma + ";publicKey:"+ publicKey;


                                    } catch (NoSuchAlgorithmException e) {
                                        e.printStackTrace();
                                    } catch (SignatureException e) {
                                        e.printStackTrace();
                                    } catch (InvalidKeyException e) {
                                        e.printStackTrace();
                                    }

                                    // 3. Enviar los datos
                                    new Thread(new ClientThread(jsonRes)).start();
                                    Toast.makeText(MainActivity.this, "Petición enviada correctamente", Toast.LENGTH_SHORT).show();
                                }
                            }

                    )
                    .

                            setNegativeButton(android.R.string.no, null)

                    .

                            show();
        }
    }
    class ClientThread implements Runnable {
        private final String message;

        ClientThread(String message) {
            this.message = message;
        }
        @Override
        public void run() {
            try {
                client = new Socket(server, port);
                printwriter = new PrintWriter(client.getOutputStream(),true);
                printwriter.write(message);

                printwriter.flush();
                printwriter.close();

                client.close();

            } catch (IOException e) {
                e.printStackTrace();
            }

        }
    }

}

